# BHEEMA AI — ویڈیو اسٹوڈیو (Web + Android starter)

یہ BHEEMA AI کا قابلِ ترمیم starter project ہے۔ اس میں React/Vite frontend، FastAPI backend اور Capacitor Android wrapper شامل ہیں۔ UI میں Text-to-Video اور Image-to-Video دونوں modes، image upload، prompt، aspect ratio، duration، generation history اور API connection موجود ہیں۔

## اہم اور صاف بات

- موجودہ `DEMO_MODE=true` صرف درخواست وصول کرکے demo status دکھاتا ہے؛ یہ خود ویڈیو render نہیں کرتا۔
- Lightricks کا Hugging Face demo کامیابی سے چل جانا اس بات کا ثبوت ہے کہ آپ نے demo استعمال کیا، لیکن اس سے BHEEMA AI کو کوئی مستقل یا مفت API خودبخود نہیں ملتی۔
- حقیقی ویڈیو بنانے کے لیے GPU پر ComfyUI، compatible model، اور دونوں modes کے API-format workflows درکار ہیں۔ موبائل فون اکیلا یہ بڑے models عموماً نہیں چلا سکتا۔
- اس ZIP میں APK/AAB، hosted website، production GPU backend، login یا public-user security شامل نہیں۔ ان کے بغیر اسے عوامی production app کہنا درست نہیں ہوگا۔

## فولڈر

- `frontend/` — ویب UI اور Android wrapper
- `backend/` — FastAPI generation API
- `backend/workflows/` — آپ کے ComfyUI API workflows رکھنے کی جگہ (ابتدا میں خالی)

## ویب UI اور API چلانا

ضروری: کمپیوٹر/سرور پر Python 3.10+ اور Node.js 20+۔ صرف Android فون پر یہ development environment چلانا مشکل ہے۔

### Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### Frontend

نئی terminal میں:

```bash
cd frontend
npm install
cp .env.example .env
# .env میں VITE_API_URL کو backend کے address پر set کریں
npm run dev
```

## حقیقی generation جوڑنا

1. ComfyUI کو compatible video model/nodes کے ساتھ GPU machine پر چلائیں۔
2. ComfyUI میں workflow کو **Save (API Format)** کریں۔
3. Text-to-Video workflow کو `backend/workflows/text_to_video_api.json` اور Image-to-Video workflow کو `backend/workflows/image_to_video_api.json` کے نام سے رکھیں۔
4. Workflow کے متعلقہ node inputs میں placeholders استعمال کریں: `__PROMPT__`, `__NEGATIVE_PROMPT__`, `__IMAGE_PATH__`, `__SEED__`۔ یہ placeholders اسی وقت کام کریں گے جب آپ انہیں درست node fields میں رکھیں۔
5. `backend/.env` میں `DEMO_MODE=false` اور `COMFYUI_URL` سیٹ کریں۔
6. Image workflow میں uploaded image path کو ComfyUI کے قابلِ رسائی طریقے سے فراہم کرنا ضروری ہے۔ اگر ComfyUI الگ server پر ہے تو موجودہ سادہ path-sharing کافی نہیں؛ ComfyUI upload endpoint یا مشترکہ storage integration بنائیں۔

ہر model/workflow کے node names اور inputs مختلف ہو سکتے ہیں؛ صرف فائل کا نام بدلنے سے workflow compatible نہیں بنتا۔ Model license بھی public/commercial استعمال سے پہلے چیک کریں۔

## Android APK بنانے کا راستہ

Android build کے لیے Android Studio/SDK اور Node.js والا کمپیوٹر یا cloud build environment چاہیے:

```bash
cd frontend
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio میں Build > Build APK(s) منتخب کریں۔ APK میں API URL کو آپ کے deployed HTTPS backend کی طرف ہونا چاہیے۔ `localhost` فون پر خود فون کو ظاہر کرتا ہے، آپ کے کمپیوٹر کو نہیں۔

## عوامی لانچ سے پہلے لازمی کام

Authentication، per-user quotas، upload size/type validation، persistent job database، object storage، queue، HTTPS، rate limits، cleanup، error handling، privacy policy، abuse controls اور GPU capacity شامل کریں۔ ComfyUI کو براہِ راست public internet پر expose نہ کریں۔

## صفر بجٹ کے بارے میں

اس وقت اس project کو مفت میں develop/test کیا جا سکتا ہے، لیکن مستقل public AI video generation کے لیے GPU compute اور hosting درکار ہوں گے۔ Free demo/ZeroGPU کی availability اور quota بدل سکتی ہے۔ Google Play پر اشاعت کے لیے Play Console registration بھی درکار ہوتا ہے؛ یہ starter خودکار طور پر publish نہیں کرتا۔
