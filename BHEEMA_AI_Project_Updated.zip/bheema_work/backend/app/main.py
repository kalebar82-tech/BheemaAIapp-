import json, os, uuid, asyncio, time
from pathlib import Path
from typing import Optional
import httpx
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from .config import settings

ROOT = Path(__file__).resolve().parent.parent
UPLOADS = ROOT / "uploads"
OUTPUTS = ROOT / "outputs"
WORKFLOWS = ROOT / settings.workflow_dir
for p in (UPLOADS, OUTPUTS, WORKFLOWS):
    p.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="BHEEMA AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"]
)
app.mount("/uploads", StaticFiles(directory=UPLOADS), name="uploads")
app.mount("/outputs", StaticFiles(directory=OUTPUTS), name="outputs")

jobs = {}

@app.get("/")
def root():
    return {"name": "BHEEMA AI", "status": "online", "demo_mode": settings.demo_mode}

@app.get("/api/health")
def health():
    return {"ok": True, "demo_mode": settings.demo_mode, "comfyui_url": settings.comfyui_url}

def replace_placeholders(value, prompt, negative, image_path, seed):
    if isinstance(value, dict):
        return {k: replace_placeholders(v, prompt, negative, image_path, seed) for k, v in value.items()}
    if isinstance(value, list):
        return [replace_placeholders(v, prompt, negative, image_path, seed) for v in value]
    if isinstance(value, str):
        return (value.replace("__PROMPT__", prompt)
                     .replace("__NEGATIVE_PROMPT__", negative)
                     .replace("__IMAGE_PATH__", image_path or "")
                     .replace("__SEED__", str(seed)))
    return value

async def submit_comfy_job(job_id, mode, prompt, negative, image_path, seed):
    workflow_file = WORKFLOWS / f"{mode}_api.json"
    if not workflow_file.exists():
        jobs[job_id]["status"] = "error"
        jobs[job_id]["error"] = f"Missing workflow: {workflow_file.name}. Export a ComfyUI API workflow first."
        return
    try:
        workflow = json.loads(workflow_file.read_text(encoding="utf-8"))
        workflow = replace_placeholders(workflow, prompt, negative, image_path, seed)
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(f"{settings.comfyui_url}/prompt", json={"prompt": workflow})
            response.raise_for_status()
            prompt_id = response.json()["prompt_id"]
            jobs[job_id]["comfy_prompt_id"] = prompt_id
            jobs[job_id]["status"] = "queued"
            while True:
                await asyncio.sleep(3)
                history = await client.get(f"{settings.comfyui_url}/history/{prompt_id}")
                history.raise_for_status()
                data = history.json().get(prompt_id, {})
                outputs = data.get("outputs", {})
                videos = []
                for node in outputs.values():
                    for key in ("videos", "gifs"):
                        for item in node.get(key, []):
                            filename = item.get("filename")
                            subfolder = item.get("subfolder", "")
                            if filename:
                                videos.append({"filename": filename, "subfolder": subfolder, "type": item.get("type", "output")})
                if videos:
                    jobs[job_id]["status"] = "completed"
                    jobs[job_id]["result"] = {"comfyui_files": videos, "message": "Generation complete in ComfyUI. Retrieve the output from its configured output folder."}
                    return
    except Exception as exc:
        jobs[job_id]["status"] = "error"
        jobs[job_id]["error"] = str(exc)

@app.post("/api/generate")
async def generate(
    mode: str = Form(...),
    prompt: str = Form(...),
    negative_prompt: str = Form(""),
    aspect_ratio: str = Form("16:9"),
    duration: int = Form(5),
    image: Optional[UploadFile] = File(None)
):
    if mode not in ("text_to_video", "image_to_video"):
        raise HTTPException(400, "Unsupported generation mode")
    if not prompt.strip():
        raise HTTPException(400, "Prompt is required")
    if mode == "image_to_video" and image is None:
        raise HTTPException(400, "Please upload an image for Image-to-Video")
    image_path = None
    if image:
        ext = Path(image.filename or "image.png").suffix.lower()
        if ext not in (".png", ".jpg", ".jpeg", ".webp"):
            raise HTTPException(400, "Image must be PNG, JPG, or WEBP")
        image_path = UPLOADS / f"{uuid.uuid4().hex}{ext}"
        image_path.write_bytes(await image.read())
    job_id = uuid.uuid4().hex
    jobs[job_id] = {
        "id": job_id, "mode": mode, "prompt": prompt, "status": "processing" if settings.demo_mode else "submitting",
        "created_at": time.time(), "aspect_ratio": aspect_ratio, "duration": duration,
        "image_url": f"/uploads/{image_path.name}" if image_path else None
    }
    if settings.demo_mode:
        jobs[job_id]["status"] = "demo"
        jobs[job_id]["message"] = "Demo request received. Connect ComfyUI and an API workflow to render a real video."
    else:
        asyncio.create_task(submit_comfy_job(job_id, mode, prompt, negative_prompt, str(image_path) if image_path else None, int(time.time())))
    return jobs[job_id]

@app.get("/api/jobs")
def list_jobs():
    return sorted(jobs.values(), key=lambda x: x["created_at"], reverse=True)

@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    return jobs[job_id]
