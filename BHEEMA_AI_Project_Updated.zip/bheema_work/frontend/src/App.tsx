import { useEffect, useState } from 'react';
import { Film, Image as ImageIcon, WandSparkles, Download, Clock3, Settings2, Upload, Play, Sparkles, Menu, Plus, Clapperboard } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';
type Job = { id:string; mode:string; prompt:string; status:string; created_at:number; message?:string; error?:string; result?:any; image_url?:string; aspect_ratio?:string; duration?:number };
export default function App() {
  const [mode,setMode] = useState<'text_to_video'|'image_to_video'>('text_to_video');
  const [prompt,setPrompt] = useState('');
  const [negative,setNegative] = useState('');
  const [ratio,setRatio] = useState('16:9');
  const [duration,setDuration] = useState('5');
  const [file,setFile] = useState<File|null>(null);
  const [preview,setPreview] = useState('');
  const [jobs,setJobs] = useState<Job[]>([]);
  const [busy,setBusy] = useState(false);
  const [notice,setNotice] = useState('Ready to create');
  const [menu,setMenu] = useState(false);

  async function refresh() { try { const r=await fetch(`${API}/api/jobs`); if(r.ok) setJobs(await r.json()); } catch {} }
  useEffect(()=>{ refresh(); const t=setInterval(refresh,4000); return ()=>clearInterval(t); },[]);
  function chooseFile(f:File|null) { setFile(f); setPreview(f?URL.createObjectURL(f):''); }
  async function generate() {
    if(!prompt.trim()) { setNotice('Please write a video prompt first.'); return; }
    if(mode==='image_to_video'&&!file) { setNotice('Please upload an image first.'); return; }
    setBusy(true); setNotice('Sending your request…');
    const data=new FormData(); data.append('mode',mode); data.append('prompt',prompt); data.append('negative_prompt',negative); data.append('aspect_ratio',ratio); data.append('duration',duration); if(file) data.append('image',file);
    try { const r=await fetch(`${API}/api/generate`,{method:'POST',body:data}); const body=await r.json(); if(!r.ok) throw new Error(body.detail||'Request failed'); setNotice(body.message||`Request created · ${body.status}`); setPrompt(''); await refresh(); }
    catch(e:any) { setNotice(e.message||'Could not reach the BHEEMA AI server.'); }
    finally { setBusy(false); }
  }
  return <div className="app">
    <aside className={`sidebar ${menu?'open':''}`}>
      <div className="brand"><div className="brandmark"><Clapperboard size={22}/></div><div><b>BHEEMA <span>AI</span></b><small>VIDEO STUDIO</small></div></div>
      <button className="nav active"><WandSparkles size={18}/> Create video</button>
      <button className="nav" onClick={refresh}><Film size={18}/> My generations</button>
      <div className="side-bottom"><div className="gpu-card"><Sparkles size={17}/><b>Open-source studio</b><p>Connect your own local AI engine to render videos.</p></div><div className="profile"><div className="avatar">B</div><div><b>Creator</b><small>Personal workspace</small></div><Settings2 size={17}/></div></div>
    </aside>
    <main className="main">
      <header><button className="mobile-menu" onClick={()=>setMenu(!menu)}><Menu/></button><div><span className="eyebrow">AI CREATION WORKSPACE</span><h1>Video Studio</h1></div><div className="header-right"><span className="status-dot"></span> Studio ready</div></header>
      <section className="hero"><div><div className="eyebrow purple">YOUR IDEAS, IN MOTION</div><h2>Imagine it.<br/><em>Bring it to life.</em></h2><p>Create cinematic videos from a simple text prompt or a still image.</p></div><div className="hero-art"><div className="orb"></div><div className="art-chip"><Sparkles size={14}/> AI VIDEO</div></div></section>
      <div className="workspace">
        <section className="panel create-panel">
          <div className="panel-title"><div><span className="eyebrow">01 / INPUT</span><h3>Start creating</h3></div><span className="pill"><span className="status-dot"></span> New project</span></div>
          <div className="mode-switch">
            <button className={mode==='text_to_video'?'selected':''} onClick={()=>setMode('text_to_video')}><Film size={17}/> Text to Video</button>
            <button className={mode==='image_to_video'?'selected':''} onClick={()=>setMode('image_to_video')}><ImageIcon size={17}/> Image to Video</button>
          </div>
          {mode==='image_to_video'&&<label className="upload-zone">{preview?<img src={preview}/>:<><Upload size={25}/><b>Upload a starting image</b><span>PNG, JPG or WEBP</span></>}<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>chooseFile(e.target.files?.[0]||null)}/></label>}
          <label className="field-label">YOUR PROMPT <span>Describe the video you imagine</span></label>
          <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="A majestic snow leopard walking through a misty Himalayan forest at sunrise, cinematic camera movement, realistic details…" rows={5}/>
          <label className="field-label">NEGATIVE PROMPT <span>Optional</span></label>
          <input className="text-input" value={negative} onChange={e=>setNegative(e.target.value)} placeholder="blurry, low quality, distorted…"/>
          <div className="settings-row"><div><label className="field-label">ASPECT RATIO</label><select value={ratio} onChange={e=>setRatio(e.target.value)}><option>16:9</option><option>9:16</option><option>1:1</option><option>4:3</option></select></div><div><label className="field-label">DURATION</label><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="5">5 seconds</option><option value="8">8 seconds</option><option value="10">10 seconds</option></select></div></div>
          <button className="generate" onClick={generate} disabled={busy}>{busy?<span className="spinner"/>:<WandSparkles size={18}/>} {busy?'Submitting…':'Generate video'} <span className="arrow">→</span></button>
          <div className="notice">{notice}</div>
          <p className="fineprint">Generation requires a connected ComfyUI workflow and compatible model. Demo mode previews the app flow only.</p>
        </section>
        <section className="panel history-panel">
          <div className="panel-title"><div><span className="eyebrow">02 / LIBRARY</span><h3>Recent creations</h3></div><button className="icon-button" onClick={refresh}><Clock3 size={17}/></button></div>
          {jobs.length===0?<div className="empty"><div className="empty-icon"><Film size={27}/></div><b>Your creative space awaits</b><p>Your generated videos and requests will appear here.</p><button onClick={()=>window.scrollTo({top:0,behavior:'smooth'})}><Plus size={16}/> New generation</button></div>:
          <div className="job-list">{jobs.map(j=><div className="job" key={j.id}><div className="job-thumb">{j.image_url?<img src={`${API}${j.image_url}`}/>:<Film size={23}/>}<span><Play size={12}/></span></div><div className="job-info"><b>{j.prompt}</b><small>{j.mode==='text_to_video'?'Text to Video':'Image to Video'} · {new Date(j.created_at*1000).toLocaleString()}</small><small className={`job-status ${j.status}`}>{j.status.toUpperCase()}</small>{j.error&&<small className="error">{j.error}</small>}</div></div>)}</div>}
          <div className="engine-note"><Sparkles size={16}/><div><b>Bring your own AI engine</b><p>Connect ComfyUI locally for open-source video generation. No paid API is required by this starter.</p></div></div>
        </section>
      </div>
      <footer><span>© 2026 BHEEMA AI</span><span>Built for creators · Open-source foundation</span></footer>
    </main>
  </div>
}
